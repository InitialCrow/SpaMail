<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<body>
<div style="height:15px;"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#EEEEEE">
<tr>
<td>
<div style="height:15px;"></div>
<table width="1000" border="0" cellspacing="0" cellpadding="0" align="center">
<tr>
<td style="padding:0 15px 0 15px;">
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td style="background-color: #06C" height="1" colspan="3"></td>
</tr>
<tr>
<td style="background-color: #06C" width="1"></td>
<td style="background-color: #F7FAFD">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
  <td style="background-color:#005598; width:238px;" valign="top">
  <br />
  <a href="{LIEN_SITE}" target="_blank"><img src="http://www.lafml.org/img/NewLogoCarre.jpg" border="0" alt=""></a>
  </td>
    <td valign="top">
    <div style="font: normal 12px Verdana; padding: 20px 10px 20px 10px; text-align: justify;"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td style="font-size:13px; color:#005598;">{SUJET}</td>
          </tr>
		  <tr>
            <td height="10px;"></td>
          </tr
          ><tr>
            <td height="1" bgcolor="#005598"></td>
          </tr>
		  <tr>
            <td height="20px;"></td>
          </tr>
          <tr>
            <td style="font-size:12px;">{MESSAGE}</td>
          </tr>
          <tr>
            <td height="20px;"></td>
          </tr>
          <tr>
            <td style="font-size:13px;">Cordialement,<br />L'équipe de l'Association pour la Formation des Médecins Libéraux</td>
          </tr>
		  {EXPEDITEUR}
        </table>
    </div> 
	</td>
  </tr>
</table>

</td>
<td style="background-color: #06C" width="1"></td>
</tr>
<tr>
<td style="background-color: #06C" height="1" colspan="3"></td>
</tr>
</table>

</td>
</tr>
<tr>
<td height="25">
<div style="color: #666; font: normal 11px Verdana; padding: 20px; text-align: center">Cet email est envoyé automatiquement, veuillez ne PAS y répondre<br />
- Copyright © {URL_SITE} -</div>
</td>
</tr>
</table>
<div style="height:15px;"></div>
</td>
</tr>
</table>
</body>
</html>