
{SUJET}
------------------------------------------------------------------------------------------------------

{MESSAGE}

Cordialement, 
L'équipe de l'Association pour la Formation des Médecins Libéraux

------------------------------------------------------------------------------------------------------

Cet email est envoyé automatiquement, veuillez ne PAS y répondre.

{EXPEDITEUR}
{URL_SITE}
