
{SUJET}
------------------------------------------------------------------------------------------------------

{MESSAGE}


------------------------------------------------------------------------------------------------------

Cet email vous a été envoyé depuis le site.
Vous pouvez directement répondre à votre interlocuteur à partir de cet email.

{URL_SITE}
