﻿<?php
include '_parametres/configSMTP/Config.php';

/**
 * 
 * 		AJOUT GFR 01/09/2015
 *  			
 * 		array elements :
 * 			$_element["titre"]
 * 			$_element["txt"]
 * 			$_element["name_site"]
 * 			$_element["logo"]
 * 			$_element["url_site"]
 * 			$_element["nom_expediteur"]
 * 			$_element["email_responsable"]
 * 
 *		/AJOUT 
 * 
 *		array pièces jointes :
 *			$_element['piece_jointe']['type']
 *			$_element['piece_jointe']['nom']
 *			$_element['piece_jointe']['extention']
 *			$_element['piece_jointe']['contenu']
 *		copie Cc
 *			$_element['Cc']
 */
function send_email($_to, $_element, $_dir_template){
	//Patch permettant de bypasser l'erreur du " [] operator not supported for strings "
	if(isset($_SESSION["SUCCESS"])) {
		if(array_key_exists("TXT", $_SESSION["SUCCESS"]) && is_string($_SESSION["SUCCESS"]["TXT"])) { 
			$tmp = $_SESSION["SUCCESS"]["TXT"];
			$_SESSION["SUCCESS"]["TXT"] = array();
			$_SESSION["SUCCESS"]["TXT"][] = $tmp;
		}
	}
	if(isset($_SESSION["ERROR"])) {
		if(array_key_exists("TXT", $_SESSION["ERROR"]) && is_string($_SESSION["ERROR"]["TXT"])) { 
			$tmp = $_SESSION["ERROR"]["TXT"];
			$_SESSION["ERROR"]["TXT"] = array();
			$_SESSION["ERROR"]["TXT"][] = $tmp;
		}
	}
	
			$txt["htxt"] = preg_replace('#^http://[a-z0-9._=:\*\#/?&-]+#i', '<a href="$0" target="_blank">$0</a>', $_element["txt"]);
			$txt["htxt"] = nl2br($txt["htxt"]);	
			$txt["htxt"] = str_replace(array("\\r\\n", "\\r", "\\n"), "<br />", $txt["htxt"]);//au cas où le nl2br ne marcherait pas
			
			$txt["html"] = file_get_contents($_dir_template."_html.php");
			$txt["html"] = str_replace("{SUJET}", $_element["titre"], $txt["html"]);
			$txt["html"] = str_replace("{MESSAGE}", $txt["htxt"], $txt["html"]);
			$txt["html"] = str_replace("{NOM_SITE}", $_element["name_site"], $txt["html"]);
			$txt["html"] = str_replace("{IMAGE_LOGO}", $_element["logo"], $txt["html"]);
			$txt["html"] = str_replace("{URL_SITE}", $_element["url_site"], $txt["html"]);
			if (isset($_element["INFOEXPEDITEUR"])) { // si INFOEXPEDITEUR n'est pas renseigné dans le template
				$txt["html"] = str_replace("{INFOEXPEDITEUR}", $_element["INFOEXPEDITEUR"], $txt["html"]);
			}

			$txt["txt"] = file_get_contents($_dir_template."_txt.php");
			$txt["txt"] = str_replace("{SUJET}", $_element["titre"], $txt["txt"]);
			$txt["txt"] = str_replace("{MESSAGE}", $_element["txt"], $txt["txt"]);
			$txt["txt"] = str_replace("{NOM_SITE}", $_element["name_site"], $txt["txt"]);
			$txt["txt"] = str_replace("{URL_SITE}", $_element["url_site"], $txt["txt"]);
			if (isset($_element["INFOEXPEDITEUR"])) {
				$txt["txt"] = str_replace("{INFOEXPEDITEUR}", $_element["INFOEXPEDITEUR"], $txt["txt"]);
			}

			$nameto = "";
			if (isset($_element["nom_expediteur"])) {
				$namefrom = $_element["nom_expediteur"];
			} else {
				$namefrom = "AFML";
			}
			
			//ajout du nom de l'expediteur dans le corp du message
			if(stripos(@$_SERVER["HTTP_REFERER"], 'envoyer_email.php') && isset($_element["nom_expediteur"])) {
				//echo $_element["nom_expediteur"];
				$expediteur = $_element["nom_expediteur"];
				$msg_exp ="<tr>
					<td>
					<div style=\"font-size:13px;color:gray;margin-top:20px;border-top:1px solid gray; padding-top:10px;\">Ce message a été envoyé par ".$expediteur." et a pour destinataire ".$_element["email_destinataire"]."</div>
					</td>
				  </tr>";
				$txt["html"] = str_replace("{EXPEDITEUR}", $msg_exp, $txt["html"]);
				$txt["txt"] = str_replace("{EXPEDITEUR}", $expediteur, $txt["txt"]);
			}
			else {
				$txt["html"] = str_replace("{EXPEDITEUR}", '', $txt["html"]);
				$txt["txt"] = str_replace("{EXPEDITEUR}", '', $txt["txt"]);
			}
				//die();

			$subject = $_element["titre"];
			$site = "AFML";
			
			// print_r($txt);
			// print_r($txt);
			// exit();
			
		$configSMTP = new Config;
		$configSMTP->idTypeConfig = 2;
		
		if($configSMTP->isActive() == TRUE) { //config SMTP personnalisée selectionnée
			
			$config = $configSMTP->getConfigSMTP();

			
					$mail = new PHPMailer;

					$mail->isSMTP();
//					$mail->SMTPDebug = true;
					$mail->Host = $config['Host'];
					$mail->Port = $config['Port'];
					$mail->SMTPAuth = true;
					$mail->Username = $config['Username'];
					$mail->Password = $config['Password'];
					$mail->SMTPSecure = $config['Encryption'];
					$mail->isHTML(true);
					$mail->CharSet = "utf-8";
					$mail->From = (!empty($_element["email_responsable"]))
							? $_element["email_responsable"]
						: $config['FromMail'];					
					$mail->FromName = (isset($expediteur))
							? $expediteur
						: $config['FromName'];

					
			if($_SERVER["SERVER_NAME"] == "www.lafml.org" or $_SERVER["SERVER_NAME"] == "ww2.lafml.org"){
				$mail->addAddress($_to);
			}elseif($_SERVER["SERVER_NAME"] == "demo.lafml.org"){
				$_SESSION["SUCCESS"]["TXT"][] = "Depuis la version démo tous les emails sont envoyés à l'email de test</br>[ demoafml@gmail.com -> afml2014 ]";
				$mail->addAddress("demoafml@gmail.com");
			}else{ //dev
				if(eregi("@kertiostechnologies.com", $_to) || eregi("@kertios.com", $_to)||  $_to=="testkertios@orange.fr"){
					$mail->addAddress($_to);
					$_SESSION["SUCCESS"]["TXT"][] = "L'Email a été envoyé à ".$_to;
				}else{
					$_SESSION["SUCCESS"]["TXT"][] = "Aucun email n'a été envoyé parce que vous êtes en dev";
				}
			}

			if(isset($_element['Cc'])) {
				if($_SERVER["SERVER_NAME"] == "www.lafml.org" || $_SERVER["SERVER_NAME"] == "ww2.lafml.org") {
					$mail->addCC(str_replace(';', ',', $_element['Cc']));
				}
			}


			if(isset($_element['piece_jointe'])) {
				foreach($_element['piece_jointe'] as $piece_jointe) {
					$encoding = "base64";
					$mail->AddStringAttachment(base64_decode($piece_jointe['contenu']), $piece_jointe['nom'].".".$piece_jointe['extention'], $encoding, $piece_jointe['type']);
				}
			}
			$mail->Subject = $subject;
			$mail->Body = $txt["html"];
			$mail->AltBody = $txt["txt"];
			$mail->send();
		} else { // envoi normal
			if(!empty($_element["email_responsable"])) {
				$from = $_element["email_responsable"];
			}
			else {
				$from = "noreply@lafml.org";
			}
			$limite = "----------=_parties_".md5(uniqid (rand()));
			$limite_piece_jointe = "----------=_parties_69".md5(uniqid (rand()));
			$header = "From: ".$namefrom." <".$from.">\n";

			if(isset($_element['Cc'])) {
				if($_SERVER["SERVER_NAME"] == "www.lafml.org" or $_SERVER["SERVER_NAME"] == "ww2.lafml.org") {
					$header .= 'Cc: '.$_element['Cc']. "\r\n";
				} else {
					$header .= "Cc: demoafml@gmail.com\r\n";			
				}
			}

			$header .= "X-Sender: <".$site.">\n";
			$header .= "X-Mailer: PHP\n";
			$header .= "X-auth-smtp-user: ".$from." \n";
			$header .= "X-abuse-contact: ".$from." \n";
			$header .= "Date: ".date("D, j M Y G:i:s O")."\n";
			$header .= "MIME-Version: 1.0\n";

			if(isset($_element['piece_jointe'])) {
				$header .= "Content-Type: multipart/mixed;\n boundary=\"".$limite_piece_jointe."\"\r\n";	
				$header .= "\r\n";
				$header .= "This is a multi-part message in MIME format.\r\n";
				$header .= "--".$limite_piece_jointe."\n";
			}
			$header .= "Content-Type: multipart/alternative;\n boundary=\"".$limite."\"\n";
			
			$message = "";
			$message .= "\n--".$limite."\r\n";
			$message .= "Content-Type: text/plain; ";
			$message .= "charset=\"utf-8\"; format=flowed\r\n";
			$message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
			$message .= $txt["txt"];
			$message .= "\n\n--".$limite."\n";
			$message .= "Content-Type: text/html; ";
			$message .= "charset=\"utf-8\"; ";
			$message .= "Content-Transfer-Encoding: 8bit;\n\n";
			$message .= $txt["html"];
			$message .= "\n--".$limite."--";
			if(isset($_element['piece_jointe'])) {
				foreach($_element['piece_jointe'] as $piece_jointe) {
					$message .= "\n";
					$message .= "--".$limite_piece_jointe."\n";	
					$message .= "Content-Type: ".$piece_jointe['type'].";\n name=\"".$piece_jointe['nom'].".".$piece_jointe['extention']."\" \n";  
					$message .= "Content-Disposition: attachment;\n filename=\"".$piece_jointe['nom'].".".$piece_jointe['extention']."\" \n";
					$message .= "Content-Transfer-Encoding: base64 \r\n\r\n";   
					$message .= "\n";  
					$message .= $piece_jointe['contenu'];  //."\r\n"
					$message .= "\r\n";  
					$message .= "--".$limite_piece_jointe;
				}
				$message .= "--";
			}

			if($_SERVER["SERVER_NAME"] == "www.lafml.org" or $_SERVER["SERVER_NAME"] == "ww2.lafml.org"){
				if(mail($_to, $subject, $message, $header)){
						$_SESSION["SUCCESS"]["TXT"][] = "L'email a été envoyé à ".$_to;
					}else{
						$_SESSION["ERROR"]["TXT"][] = "Aucun email n'a été envoyé à ".$_to;
					}
                 //Production
			}elseif($_SERVER["SERVER_NAME"] == "demo.lafml.org"){
				if(eregi("@kertiostechnologies.com", $_to) || eregi("@kertios.com", $_to)){
					if(mail($_to, $subject, $message, $header)){
						$_SESSION["SUCCESS"]["TXT"][] = "L'email a été envoyé à ".$_to;
					}else{
						$_SESSION["ERROR"]["TXT"][] = "Aucun email n'a été envoyé car erreur fonction mail().";
					}
				}else{
					if(mail("demoafml@gmail.com", $subject, $message, $header)){ // Pour la démo
						$_SESSION["SUCCESS"]["TXT"][] = "Depuis la version démo tous les emails sont envoyés à l'email de test</br>[ demoafml@gmail.com -> afml2014 ]";
					}else{
						$_SESSION["ERROR"]["TXT"][] = "Aucun email n'a été envoyé erreur envoi de mail.";
					}
				}
			}else{ //dev
				if(eregi("@kertiostechnologies.com", $_to) || eregi("@kertios.com", $_to) || $_to=="testkertios@orange.fr"){
//                    d($subject);
//                    d($message);
//                    d($header);
//                    dd($_to);
					if(mail($_to, $subject, $message, $header)===TRUE){
                        $_SESSION["SUCCESS"]["TXT"][] = "L'email a été envoyé à ".$_to;
          			}else{
						$_SESSION["ERROR"]["TXT"][] = "Aucun email n'a été envoyé  à ".$_to." car ça merde.";
					} 
				}else{
					$_SESSION["ERROR"]["TXT"][] = "Aucun email n'a été envoyé  à ".$_to." car vous êtes en dev.";
				}
			}
			// if($_SERVER["SERVER_NAME"] == "www.lafml.org" or $_SERVER["SERVER_NAME"] == "ww2.lafml.org") 
			// { 
				// mail($_to, $subject, $message, $header); //Production
			// }
			// else 
			// { 	
				// mail("demoafml@gmail.com", $subject, $message, $header); // Pour la démo
				// $_SESSION["SUCCESS"]["TXT"] = "Depuis la version démo tous les emails sont envoyés à l'email de test</br>[ demoafml@gmail.com -> afml2014 ]";
			// }
	}
}

function GetMailTxt($_IdMailText)
{
	$sql = "
			SELECT MailText.* , MailText_ChampDynamique.ChampDynamique 
			FROM `MailText`
			LEFT JOIN MailText_ChampDynamique ON MailText_ChampDynamique.IdMailText = MailText.IdMailText
			WHERE MailText.IdMailText = '".$_IdMailText."'
			";
		
	$result = mysql_query ($sql) or die(mysql_error()." -> ".$sql);
	
	$tab = array();
	while($ligne = mysql_fetch_array($result,MYSQL_ASSOC))
	{
		$tab['Champ'][] = $ligne['ChampDynamique'];
	}	

	$result = mysql_query ($sql) or die(mysql_error()." -> ".$sql);
	$ligne = mysql_fetch_array($result,MYSQL_ASSOC);
	
	$ligne['Champ'] = $tab['Champ'];
	return @$ligne;
}
?>
